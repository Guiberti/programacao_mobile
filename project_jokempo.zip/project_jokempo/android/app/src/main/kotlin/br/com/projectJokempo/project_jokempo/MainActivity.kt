package br.com.projectJokempo.project_jokempo

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
